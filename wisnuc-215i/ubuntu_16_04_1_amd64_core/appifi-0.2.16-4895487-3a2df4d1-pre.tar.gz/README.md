# appifi

appifi is a light-weight docker and btrfs volume manager.

appifi is designed to simply home user to deploy docker-based application on home server.
