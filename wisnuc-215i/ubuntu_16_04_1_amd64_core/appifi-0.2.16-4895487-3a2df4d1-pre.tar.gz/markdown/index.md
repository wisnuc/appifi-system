# FruitMix Documentation<p>
+ Getting Started<p>
  - [Deploying on Linux](https://github.com/wisnuc/fruitmix/blob/master/doc/gettingstarted/deployonlinux.md)<p>
  - [Deploying on Windows (Invalid)](https://github.com/wisnuc/fruitmix/blob/master/doc/gettingstarted/deployonwindows.md)<p>
  *PS: Install "fs-xattr" module failed, because of windows dosen't support extended attributes on its filesystems at all.*
  - [Running](https://github.com/wisnuc/fruitmix/blob/master/doc/gettingstarted/running.md)<p>
  - [RESTFUL APIs](https://github.com/wisnuc/fruitmix/blob/master/doc/gettingstarted/restfulapis.md)<p>
