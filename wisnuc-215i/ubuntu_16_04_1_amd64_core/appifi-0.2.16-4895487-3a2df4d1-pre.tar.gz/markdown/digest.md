# GET ALL I CAN VIEW

There are two ways to traverse file system to collect all media files a user can read for a given type.

The first is to start from a root and do a visit.

The second is to traverse the digest map, and figure out which file users can access.

Shared Album
