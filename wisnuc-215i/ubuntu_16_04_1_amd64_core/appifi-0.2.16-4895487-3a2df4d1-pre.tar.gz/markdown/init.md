# init

since fruitmix is not an always available service. It should not automatically init.

sequence:

1. sysroot must be set
2. userModel
