# RESTFUL APIs

[**Click**](https://github.com/wisnuc/fruitmix/wiki)
