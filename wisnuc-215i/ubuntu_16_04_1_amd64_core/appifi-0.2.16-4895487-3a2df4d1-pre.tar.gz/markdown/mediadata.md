

```
{
  // linux file(1) command or libmagic, source version freeze 5.25

  file: {
    type: 'animation, ''audio', 'images',
    brief: 'JPEG image data, ...',
    mimeType: '....'
  }

  animation: {

    ffmpeg: {

    }
  }

  audio: {
    id3: {

    }
  }

  images: {
    gm: {

    }
  }
}

```
