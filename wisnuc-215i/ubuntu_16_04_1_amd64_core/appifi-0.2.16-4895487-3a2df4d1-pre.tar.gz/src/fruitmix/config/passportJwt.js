export const secret = 'JsonWebTokenIsAwesome'
